package page;

import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class StarterOfGrid {
	
	@Test
	public void Test2() {
		try {
			DesiredCapabilities cap = DesiredCapabilities.firefox();
			cap.setPlatform(Platform.WINDOWS);
			URL url = new URL("http://localhost:4444/wd/hub");
			WebDriver driver = new RemoteWebDriver(url, cap);
			
			driver.get("https://web.facebook.com/");
			System.out.println("T�tulo da p�gina: " +driver.getTitle());
		} catch (Exception e) {
			System.out.println("Mensagem de erro" + e);
		}
	}

}
