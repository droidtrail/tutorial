package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

public class JavaSample_Safari_Browser {

  public static final String USERNAME = "leandropereira2";
  public static final String AUTOMATE_KEY = "1rTfUEF7Yy49e56etj9r";
  public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";

  public static void main(String[] args) throws Exception {

    DesiredCapabilities caps = DesiredCapabilities.safari();
    caps.setPlatform(Platform.MAC);
    caps.setCapability("browserstack.debug", "true");
  
    WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
    
    driver.get("https://web.facebook.com/");
    driver.findElement(By.id("email")).sendKeys("leanro.nares@gmail.com");
    driver.findElement(By.id("pass")).sendKeys("778540");
    driver.findElement(By.id("u_0_3")).click();
    
    System.out.println(driver.getTitle());
    driver.quit();

  }
}
