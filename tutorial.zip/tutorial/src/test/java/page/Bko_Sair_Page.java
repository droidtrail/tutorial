package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Bko_Sair_Page {
	WebDriver driver;

	public Bko_Sair_Page(WebDriver driver) {
		this.driver = driver;
	}
	//M�todo sair
	public void sair_Aplica��o(String sair) {
		driver.findElement(By.id(sair)).click();
	}
	
	

}
