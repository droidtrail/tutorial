package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Bko_Logar_Page {
	
	static WebDriver driver;

	public Bko_Logar_Page(WebDriver driver) {
		this.driver = driver;
	}	
	public void confBrowser(String browser, String caminhoBrowser, String site) {
		System.setProperty(browser, caminhoBrowser);
		driver = new ChromeDriver();
		driver.get(site);
		driver.manage().window().maximize();	
	}
	public void logarBko(String id_usuario, 
									 String id_senha, 
									 String usuario, 
									 String senha,
									 String id_btnLogar ){
		driver.findElement(By.id(id_usuario)).sendKeys(usuario);
		driver.findElement(By.id(id_senha)).sendKeys(senha);
		//driver.findElement(By.partialLinkText(id_btnLogar));
		driver.findElement(By.id(id_btnLogar)).click();
		
		
	}
	
	

}
