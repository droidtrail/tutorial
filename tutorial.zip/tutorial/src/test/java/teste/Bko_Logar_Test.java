package teste;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import page.Bko_Logar_Page;
import page.Bko_Sair_Page;

public class Bko_Logar_Test {
	
	static WebDriver driver;
	static Bko_Logar_Page bko_Logar_Page;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		bko_Logar_Page = new Bko_Logar_Page(driver);
		bko_Logar_Page.confBrowser("webdriver.chrome.driver", "c:\\chromedriver.exe", "https://pt-br.facebook.com/");
	}
	@Test
	public void test() {
		bko_Logar_Page.logarBko("email", "pass", "leandro.nares@gmail.com", "778540", "u_0_2");
	}
	@AfterClass
	public static void tearDown() throws Exception {
		Thread.sleep(2000);
		driver.close();
	}

}
