package webElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class findElements3 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "d:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");

		try {
			// Armazenando todas as TAGs do tipo "a" em um List Elements
			List<WebElement> objLinks = driver.findElements(By.tagName("a"));

			// Varrendo o List Elements
			for (WebElement objCurrentLink : objLinks) {

				String strLinkText = objCurrentLink.getText();

				if (strLinkText.equalsIgnoreCase("Hotels")) {

					objCurrentLink.click();
				}
			}
		} catch (Exception e) {
			System.out.println("Mensagem de erro: " + e);
		}
	}
}
