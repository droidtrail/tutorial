package webElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class findElements2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "d:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");
		
		//Armazenando todas as TAGs do tipo "a" em um List Elements
		List<WebElement> objLinks = driver.findElements(By.tagName("a"));
		
		//Varrendo o List Elements
		for (WebElement objCurrentLink : objLinks) {
			
			String strLinkText = objCurrentLink.getText();
			
			//Imprimindo na tela os valores encontrados
			System.out.println(strLinkText);
			
		} 

	}

}
