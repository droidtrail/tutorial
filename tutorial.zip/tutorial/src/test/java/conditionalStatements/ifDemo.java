package conditionalStatements;

public class ifDemo {

	public static void main(String[] args) {
		
		System.out.println("In�cio do Teste");
		
		int a = 90;
		
		if(a < 100) {
			System.out.println("Primeiro IF. O valor �: " +a);
		}
		if(a < 50) {
			System.out.println("Segundo IF.O valor �: " +a);
		}
		System.out.println("Final do Teste");
	}

}
