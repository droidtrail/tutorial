package conditionalStatements;

public class SwitchDemo {

	public static void main(String[] args) {
		
		int x = 5;
		
		switch (x) 
		{
		case 1: 
			System.out.println("o desempenho � ruim"	);
			break;
			
		case 2:
			System.out.println("O desempenho � baixo");
			break;
			
		case 3:
			System.out.println("O desempenho est� melhorando");
			break;
			
		case 4:
			System.out.println("O desempenho � bom");
			break;
			
			default:
				System.out.println("Voc� est� demitido");
		}

	}

}
