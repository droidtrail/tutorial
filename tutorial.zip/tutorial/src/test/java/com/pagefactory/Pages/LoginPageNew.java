package com.pagefactory.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPageNew {
	
	WebDriver driver;

	public LoginPageNew(WebDriver Xdriver) {
		this.driver= Xdriver;
	}
	//Procurando o elemento pela tag nome
	@FindBy(name="username")
	@CacheLookup
	WebElement username;
	//Procurando o elemento pela tag nome
	@FindBy(how = How.NAME,using = "password")
	@CacheLookup
	WebElement password;
	
	@FindBy(how = How.XPATH,using = "//*[@id=\"loginfrm\"]/div[1]/div[5]/button")
	@CacheLookup
	WebElement submit_button;
	
	@FindBy(how = How.LINK_TEXT,using = "Forget Password")
	@CacheLookup
	WebElement Forget_Password_button;
	
	public void login_Travelagency(String uid, String pass) {
		username.sendKeys(uid);
		password.sendKeys(pass);
		submit_button.click();
		
	}

}
