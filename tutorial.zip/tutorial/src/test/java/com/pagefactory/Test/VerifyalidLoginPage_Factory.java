package com.pagefactory.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.pagefactory.Pages.LoginPageNew;
import com.wordpress.Pages.LoginPage;

import Helper.BrowserFactory;

public class VerifyalidLoginPage_Factory {
	
	@Test
	public void checkValidUser() {
		
		//This will lauch browser and specific url
		WebDriver driver = BrowserFactory.startBrowser("chrome", "http://www.phptravels.net/login");
		//Created Page Object using Page Factory
		LoginPageNew login_page = PageFactory.initElements(driver, LoginPageNew.class);
		//Call the method
		login_page.login_Travelagency("user@phptravels.com", "demouser");
		
	}

}
