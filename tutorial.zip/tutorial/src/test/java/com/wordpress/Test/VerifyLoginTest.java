/**
 * 
 */
package com.wordpress.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.wordpress.Pages.LoginPage;

/**
 * @author leand
 */
public class VerifyLoginTest {
	
	@Test
	public void verifyValidLogin() {
		System.setProperty("webdriver.gecko.driver", "d:\\geckodriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.phptravels.net/login");
		
		//Instanciando a classe LoginPage
		LoginPage login = new LoginPage(driver);
		login.userName();
		login.Password();
		login.btnLogin();
		
		//driver.quit();
	}

}
