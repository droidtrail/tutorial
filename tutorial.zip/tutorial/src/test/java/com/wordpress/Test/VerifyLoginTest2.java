/**
 * 
 */
package com.wordpress.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.wordpress.Pages.LoginPage;
import com.wordpress.Pages.LoginPage2;

/**
 * @author leand
 */
public class VerifyLoginTest2 {
	
	@Test
	public void verifyValidLogin() {
		System.setProperty("webdriver.gecko.driver", "d:\\geckodriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.phptravels.net/login");
		
		//Instanciando a classe LoginPage
		LoginPage2 login = new LoginPage2(driver);
		login.userName("user@phptravels.com");
		login.Password("demouser");
		login.btnLogin();
		
		//driver.quit();
	}

}
