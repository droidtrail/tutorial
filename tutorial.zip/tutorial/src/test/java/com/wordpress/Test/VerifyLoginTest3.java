/**
 * 
 */
package com.wordpress.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.wordpress.Pages.LoginPage;
import com.wordpress.Pages.LoginPage2;
import com.wordpress.Pages.LoginPage3;

/**
 * @author leand
 */
public class VerifyLoginTest3 {
	
	@Test
	public void verifyValidLogin() {
		System.setProperty("webdriver.gecko.driver", "d:\\geckodriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.phptravels.net/login");
		
		//Instanciando a classe LoginPage
		LoginPage3 login = new LoginPage3(driver);
		login.loginTraelagency("user@phptravels.com", "demouser");	
		//driver.quit();
	}

}
