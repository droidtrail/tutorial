/**
 * 
 */
package com.wordpress.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * @author leand
 *This class will store all the locator and methods of login page
 */
public class LoginPage2 {
	
	static WebDriver driver;

	//Fiel Email
	By field_usarname = By.name("username");
	//Fiel PassWord
	By field_password = By.name("password");
	//Button Log in
	By btn_login = By.xpath("//*[@id=\"loginfrm\"]/div[1]/div[5]/button");
	
	//builder method
	public LoginPage2(WebDriver driver) {
		this.driver = driver;
	}
	public void userName(String usarname) {
		driver.findElement(field_usarname).sendKeys(usarname);
	}
	public void Password(String password) {
		driver.findElement(field_password).sendKeys(password);
	}
	public void btnLogin() {
		driver.findElement(btn_login).click();
	}
	
}
