package dropdownDemo;

import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class SelectFacebookDropdown2 {

	@Test
	public void SelectDDownValues() {

		try {
			System.setProperty("webdriver.chrome.driver", "D:\\ChromeSelenium\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.facebook.com/");
			driver.manage().window().maximize();
			
			WebElement month_dropdown = driver.findElement(By.id("month"));
			Select mm_dd = new Select(month_dropdown);
			
			List <WebElement> dd_list = mm_dd.getOptions();
			
			//Total de meses
			int total_month = dd_list.size();
			System.out.println("Total de meses: " +total_month);
			
			//Lista dos meses
			for(WebElement ele: dd_list) {
				String month_name = ele.getText();
				System.out.println("Os meses s�o: " +month_name );	
			}
			Thread.sleep(3000);	
			driver.quit();
		} catch (Exception e) {
				System.out.println("Mensagem de erro: " +e);
		}
	}
}
