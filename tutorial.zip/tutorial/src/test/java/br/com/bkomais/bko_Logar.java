/**
 * 
 */
package br.com.bkomais;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * @author leand
 * Classe para logar no sistema
 *
 */
public class bko_Logar {
	
	WebDriver driver;

	By campoUsuario = By.id("username");
	By campoSenha = By.id("password");
	By btnLogar = By.id("");//Verificar o ID do bot�o
	
	public bko_Logar(WebDriver driver) {	
		this.driver = driver;	
	}
	
	//M�todo logar
	public void loginBkoMais(String username, String password ) {
		
	}
	

}
